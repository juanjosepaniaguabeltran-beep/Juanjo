package com.offlineai.app.ui.chat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.offlineai.app.data.db.MessageEntity
import com.offlineai.app.ui.components.ChatInputBar
import com.offlineai.app.ui.components.MessageBubble

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    messages: List<MessageEntity>,
    isGenerating: Boolean,
    isDark: Boolean,
    onBack: () -> Unit,
    onSendText: (String) -> Unit,
    onOpenCamera: () -> Unit,
    onOpenGallery: () -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Asistente sin conexión") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        },
        bottomBar = {
            Column {
                if (isGenerating) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                ChatInputBar(
                    text = inputText,
                    onTextChange = { inputText = it },
                    onSend = {
                        onSendText(inputText)
                        inputText = ""
                    },
                    onOpenCamera = onOpenCamera,
                    onOpenGallery = onOpenGallery,
                    enabled = !isGenerating
                )
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.padding(padding).fillMaxSize()
        ) {
            items(messages, key = { it.id }) { msg ->
                MessageBubble(message = msg, isDark = isDark)
            }
        }
    }
}
