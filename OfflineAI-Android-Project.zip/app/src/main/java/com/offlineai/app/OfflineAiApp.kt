package com.offlineai.app

import android.app.Application
import com.offlineai.app.ai.LocalLlmEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class OfflineAiApp : Application() {

    lateinit var llmEngine: LocalLlmEngine
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        llmEngine = LocalLlmEngine(this)
        // Carga el modelo local en segundo plano para no bloquear el arranque.
        appScope.launch {
            llmEngine.initialize()
        }
    }
}
