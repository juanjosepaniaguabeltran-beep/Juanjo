package com.offlineai.app.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryLight = Color(0xFF3D5AFE)
val PrimaryDark = Color(0xFF8C9EFF)
val BackgroundLight = Color(0xFFF7F8FC)
val BackgroundDark = Color(0xFF121218)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1E1E26)
val BubbleUserLight = Color(0xFF3D5AFE)
val BubbleUserDark = Color(0xFF4C5FE0)
val BubbleAssistantLight = Color(0xFFEDEEF5)
val BubbleAssistantDark = Color(0xFF2A2A34)
