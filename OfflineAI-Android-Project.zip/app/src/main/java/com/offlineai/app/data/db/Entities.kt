package com.offlineai.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Una conversación (equivalente a un "chat" en ChatGPT).
 */
@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Un mensaje dentro de una conversación. Puede llevar texto, una imagen local
 * (ruta en almacenamiento interno) y/o el texto extraído por OCR.
 */
@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("conversationId")]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String, // "user" o "assistant"
    val text: String,
    val imagePath: String? = null,   // ruta local de la imagen adjunta, si la hay
    val ocrText: String? = null,     // texto extraído de la imagen por ML Kit OCR
    val timestamp: Long = System.currentTimeMillis()
)
