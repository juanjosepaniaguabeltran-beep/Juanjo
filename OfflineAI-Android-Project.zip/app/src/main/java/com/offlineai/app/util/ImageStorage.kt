package com.offlineai.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Guarda copias locales (privadas de la app) de las imágenes tomadas con la
 * cámara o elegidas de la galería, para que las conversaciones sigan
 * teniendo sus imágenes disponibles offline y sin depender de la galería
 * del sistema.
 */
object ImageStorage {

    private fun imagesDir(context: Context): File =
        File(context.filesDir, "images").apply { if (!exists()) mkdirs() }

    fun saveBitmap(context: Context, bitmap: Bitmap): File {
        val file = File(imagesDir(context), "${UUID.randomUUID()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        return file
    }

    fun saveFromUri(context: Context, uri: Uri): File {
        val bitmap = context.contentResolver.openInputStream(uri).use { input ->
            BitmapFactory.decodeStream(input)
        } ?: throw IllegalArgumentException("No se pudo leer la imagen seleccionada")
        return saveBitmap(context, bitmap)
    }

    fun loadBitmap(path: String): Bitmap? =
        BitmapFactory.decodeFile(path)
}
