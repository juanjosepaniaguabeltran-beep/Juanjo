package com.offlineai.app.ui.chat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offlineai.app.data.db.ConversationEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationListScreen(
    conversations: List<ConversationEntity>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onOpenConversation: (Long) -> Unit,
    onNewConversation: () -> Unit,
    onToggleTheme: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mis conversaciones") },
                actions = {
                    IconButton(onClick = onToggleTheme) {
                        Text("🌓")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewConversation) {
                Icon(Icons.Filled.Add, contentDescription = "Nueva conversación")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                placeholder = { Text("Buscar en conversaciones...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true
            )
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(conversations, key = { it.id }) { conv ->
                    ListItem(
                        headlineContent = { Text(conv.title) },
                        modifier = Modifier.clickableConversation { onOpenConversation(conv.id) }
                    )
                    Divider()
                }
            }
        }
    }
}

// Pequeño helper de extensión para mantener el ListItem legible arriba
private fun Modifier.clickableConversation(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
