package com.offlineai.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.offlineai.app.camera.CameraCaptureScreen
import com.offlineai.app.data.repository.ChatRepository
import com.offlineai.app.ui.chat.ChatScreen
import com.offlineai.app.ui.chat.ChatViewModel
import com.offlineai.app.ui.chat.ChatViewModelFactory
import com.offlineai.app.ui.chat.ConversationListScreen
import com.offlineai.app.ui.theme.OfflineAITheme
import com.offlineai.app.util.ImageStorage
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var repository: ChatRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as OfflineAiApp
        repository = ChatRepository(applicationContext, app.llmEngine)

        setContent {
            var isDarkTheme by remember { mutableStateOf<Boolean?>(null) } // null = seguir al sistema

            OfflineAITheme(darkTheme = isDarkTheme) {
                Surface(modifier = androidx.compose.ui.Modifier.fillMaxSize()) {
                    AppNavHost(
                        repository = repository,
                        isDark = isDarkTheme ?: androidx.compose.foundation.isSystemInDarkTheme(),
                        onToggleTheme = {
                            isDarkTheme = !(isDarkTheme ?: false)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AppNavHost(
    repository: ChatRepository,
    isDark: Boolean,
    onToggleTheme: () -> Unit
) {
    val navController = rememberNavController()
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    val conversations by (if (searchQuery.isBlank()) repository.getConversations()
                           else repository.searchConversations(searchQuery))
        .collectAsState(initial = emptyList())

    val viewModel: ChatViewModel = viewModel(factory = ChatViewModelFactory(repository))
    val uiState by viewModel.uiState.collectAsState()
    val messages by viewModel.messages.collectAsState()

    // Selector de imágenes de la galería (Photo Picker, sin permisos extra en Android 13+)
    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val savedFile = ImageStorage.saveFromUri(context, uri)
            val bitmap = ImageStorage.loadBitmap(savedFile.absolutePath)
            if (bitmap != null) viewModel.sendImage(bitmap, "")
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) navController.navigate("camera")
    }

    NavHost(navController = navController, startDestination = "list") {

        composable("list") {
            ConversationListScreen(
                conversations = conversations,
                searchQuery = searchQuery,
                onSearchQueryChange = { searchQuery = it },
                onOpenConversation = { id ->
                    viewModel.openConversation(id)
                    navController.navigate("chat")
                },
                onNewConversation = {
                    viewModel.startNewConversation("Nueva conversación") {
                        navController.navigate("chat")
                    }
                },
                onToggleTheme = onToggleTheme
            )
        }

        composable("chat") {
            ChatScreen(
                messages = messages,
                isGenerating = uiState.isGenerating,
                isDark = isDark,
                onBack = { navController.popBackStack() },
                onSendText = { text -> viewModel.sendText(text) },
                onOpenCamera = {
                    val granted = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED
                    if (granted) navController.navigate("camera")
                    else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                },
                onOpenGallery = {
                    galleryLauncher.launch(
                        androidx.activity.result.PickVisualMediaRequest(
                            ActivityResultContracts.PickVisualMedia.ImageOnly
                        )
                    )
                }
            )
        }

        composable("camera") {
            CameraCaptureScreen(
                onBack = { navController.popBackStack() },
                onPhotoCaptured = { bitmap ->
                    viewModel.sendImage(bitmap, "")
                    navController.popBackStack()
                }
            )
        }
    }
}
