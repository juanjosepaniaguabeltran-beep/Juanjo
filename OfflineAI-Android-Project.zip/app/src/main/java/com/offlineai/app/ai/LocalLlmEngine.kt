package com.offlineai.app.ai

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.File

/**
 * Motor de inferencia 100% local. No hace ninguna llamada de red: el modelo
 * (.task, un Gemma cuantizado a ~2-4 bits) se carga directamente desde el
 * almacenamiento del dispositivo.
 *
 * El usuario debe colocar el modelo una vez en:
 *   /data/data/com.offlineai.app/files/models/model.task
 * (ver README del proyecto para el método de descarga/copia recomendado,
 * ya que el archivo pesa entre 1 y 3 GB y no se distribuye dentro del APK).
 */
class LocalLlmEngine(private val context: Context) {

    private var llmInference: LlmInference? = null
    var isReady: Boolean = false
        private set

    fun modelFile(): File =
        File(context.filesDir, "models/model.task")

    /**
     * Inicializa el modelo. Debe llamarse una vez al arrancar la app (o al
     * entrar al chat por primera vez), desde un hilo de fondo.
     */
    fun initialize(
        maxTokens: Int = 1024,
        topK: Int = 40,
        temperature: Float = 0.6f
    ): Boolean {
        val model = modelFile()
        if (!model.exists()) {
            Log.w(TAG, "Modelo no encontrado en ${model.absolutePath}")
            isReady = false
            return false
        }
        return try {
            val options = LlmInferenceOptions.builder()
                .setModelPath(model.absolutePath)
                .setMaxTokens(maxTokens)
                .setTopK(topK)
                .setTemperature(temperature)
                .build()
            llmInference = LlmInference.createFromOptions(context, options)
            isReady = true
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error al inicializar el modelo local", e)
            isReady = false
            false
        }
    }

    /**
     * Genera una respuesta completa de una sola vez (bloqueante, llamar desde
     * un dispatcher de fondo tipo Dispatchers.Default/IO).
     */
    fun generateResponse(prompt: String): String {
        val engine = llmInference ?: return "El modelo local todavía no está cargado."
        return try {
            engine.generateResponse(buildPrompt(prompt))
        } catch (e: Exception) {
            Log.e(TAG, "Error generando respuesta", e)
            "Ocurrió un error al generar la respuesta localmente."
        }
    }

    /**
     * Versión en streaming (token a token) para mostrar la respuesta
     * progresivamente en el chat, igual que hace ChatGPT.
     */
    fun generateResponseStream(prompt: String): Flow<String> = callbackFlow {
        val engine = llmInference
        if (engine == null) {
            trySend("El modelo local todavía no está cargado.")
            close()
            return@callbackFlow
        }
        try {
            engine.generateResponseAsync(buildPrompt(prompt)) { partialResult, done ->
                trySend(partialResult)
                if (done) close()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error en streaming", e)
            trySend("Ocurrió un error al generar la respuesta localmente.")
            close()
        }
        awaitClose { }
    }

    /**
     * Construye el prompt final combinando la instrucción de sistema (tutor
     * paso a paso) con la pregunta/texto OCR del usuario.
     */
    private fun buildPrompt(userInput: String): String = """
        Eres un asistente educativo que responde SIEMPRE en español, de forma
        clara y explicando paso a paso cuando resuelvas ejercicios de
        matemáticas, ciencias, historia, inglés u otras materias.

        Pregunta o contenido del usuario:
        $userInput
    """.trimIndent()

    fun close() {
        llmInference?.close()
        llmInference = null
        isReady = false
    }

    companion object {
        private const val TAG = "LocalLlmEngine"
    }
}
