package com.offlineai.app.ui.chat

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.offlineai.app.data.db.MessageEntity
import com.offlineai.app.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val conversationId: Long? = null,
    val isGenerating: Boolean = false,
    val modelReady: Boolean = true
)

class ChatViewModel(private val repository: ChatRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState

    private val conversationIdFlow = MutableStateFlow<Long?>(null)

    val messages: StateFlow<List<MessageEntity>> = conversationIdFlow
        .flatMapLatest { id ->
            if (id == null) kotlinx.coroutines.flow.flowOf(emptyList())
            else repository.getMessages(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun openConversation(id: Long) {
        conversationIdFlow.value = id
        _uiState.update { it.copy(conversationId = id) }
    }

    fun startNewConversation(firstMessagePreview: String, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val title = firstMessagePreview.take(40).ifBlank { "Nueva conversación" }
            val id = repository.createConversation(title)
            openConversation(id)
            onCreated(id)
        }
    }

    fun sendText(text: String) {
        val convId = _uiState.value.conversationId ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true) }
            repository.sendTextMessage(convId, text)
            _uiState.update { it.copy(isGenerating = false) }
        }
    }

    fun sendImage(bitmap: Bitmap, question: String) {
        val convId = _uiState.value.conversationId ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true) }
            repository.sendImageMessage(convId, bitmap, question)
            _uiState.update { it.copy(isGenerating = false) }
        }
    }
}
