package com.offlineai.app.data.repository

import android.content.Context
import android.graphics.Bitmap
import com.offlineai.app.ai.LocalLlmEngine
import com.offlineai.app.ai.OcrHelper
import com.offlineai.app.data.db.AppDatabase
import com.offlineai.app.data.db.ConversationEntity
import com.offlineai.app.data.db.MessageEntity
import com.offlineai.app.util.ImageStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Única fuente de verdad para la UI: guarda mensajes, ejecuta OCR sobre las
 * imágenes y pide la respuesta al modelo de IA local. Todo el flujo
 * funciona sin ninguna llamada de red.
 */
class ChatRepository(
    private val context: Context,
    private val llmEngine: LocalLlmEngine
) {
    private val dao = AppDatabase.getInstance(context).chatDao()

    fun getConversations(): Flow<List<ConversationEntity>> = dao.getAllConversations()

    fun searchConversations(query: String): Flow<List<ConversationEntity>> =
        dao.searchConversations(query)

    fun getMessages(conversationId: Long): Flow<List<MessageEntity>> =
        dao.getMessagesForConversation(conversationId)

    suspend fun createConversation(title: String): Long = withContext(Dispatchers.IO) {
        dao.insertConversation(ConversationEntity(title = title))
    }

    /**
     * Envía un mensaje de texto del usuario y devuelve la respuesta del modelo local.
     */
    suspend fun sendTextMessage(conversationId: Long, text: String): MessageEntity =
        withContext(Dispatchers.IO) {
            dao.insertMessage(
                MessageEntity(conversationId = conversationId, role = "user", text = text)
            )
            val answer = llmEngine.generateResponse(text)
            val assistantMsg = MessageEntity(
                conversationId = conversationId,
                role = "assistant",
                text = answer
            )
            dao.insertMessage(assistantMsg)
            assistantMsg
        }

    /**
     * Envía una imagen (foto o de galería) junto con una pregunta opcional.
     * Pipeline: guarda la imagen localmente -> OCR local -> IA local con el
     * texto extraído + la pregunta del usuario.
     */
    suspend fun sendImageMessage(
        conversationId: Long,
        bitmap: Bitmap,
        userQuestion: String
    ): MessageEntity = withContext(Dispatchers.IO) {
        val savedFile = ImageStorage.saveBitmap(context, bitmap)
        val extractedText = runCatching { OcrHelper.recognizeText(bitmap) }.getOrDefault("")

        dao.insertMessage(
            MessageEntity(
                conversationId = conversationId,
                role = "user",
                text = userQuestion,
                imagePath = savedFile.absolutePath,
                ocrText = extractedText
            )
        )

        val prompt = buildString {
            if (extractedText.isNotBlank()) {
                append("Texto detectado en la imagen (por OCR):\n")
                append(extractedText)
                append("\n\n")
            }
            append(
                if (userQuestion.isNotBlank()) userQuestion
                else "Analiza esta imagen/ejercicio y explica la solución paso a paso."
            )
        }

        val answer = llmEngine.generateResponse(prompt)
        val assistantMsg = MessageEntity(
            conversationId = conversationId,
            role = "assistant",
            text = answer
        )
        dao.insertMessage(assistantMsg)
        assistantMsg
    }
}
