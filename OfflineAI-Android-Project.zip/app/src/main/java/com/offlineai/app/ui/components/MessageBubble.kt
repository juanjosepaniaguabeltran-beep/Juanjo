package com.offlineai.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.offlineai.app.data.db.MessageEntity
import com.offlineai.app.ui.theme.BubbleAssistantDark
import com.offlineai.app.ui.theme.BubbleAssistantLight
import com.offlineai.app.ui.theme.BubbleUserDark
import com.offlineai.app.ui.theme.BubbleUserLight

@Composable
fun MessageBubble(message: MessageEntity, isDark: Boolean) {
    val isUser = message.role == "user"
    val bubbleColor = when {
        isUser && isDark -> BubbleUserDark
        isUser && !isDark -> BubbleUserLight
        !isUser && isDark -> BubbleAssistantDark
        else -> BubbleAssistantLight
    }
    val textColor = if (isUser) MaterialTheme.colorScheme.onPrimary
                     else MaterialTheme.colorScheme.onSurface

    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            modifier = Modifier.widthIn(max = 300.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = bubbleColor)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                message.imagePath?.let { path ->
                    AsyncImage(
                        model = path,
                        contentDescription = "Imagen adjunta",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .padding(bottom = 6.dp)
                    )
                }
                if (message.text.isNotBlank()) {
                    Text(text = message.text, color = textColor, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
