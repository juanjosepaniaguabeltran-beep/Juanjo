# Asistente IA Offline — proyecto Android (Kotlin + Compose)

App tipo ChatGPT que funciona **100% sin internet**: chat, cámara/galería, OCR
local, resolución de ejercicios paso a paso, historial y búsqueda, y modo
claro/oscuro.

## Cómo abrir el proyecto

1. Abre **Android Studio** (versión Koala 2024.1 o superior).
2. `File → Open` y selecciona esta carpeta (`OfflineAI/`).
3. Deja que Gradle sincronice (necesita internet solo para descargar las
   *librerías* de compilación la primera vez; la app final no usa internet).

## Paso obligatorio: instalar el modelo de IA local

El motor de IA (MediaPipe LLM Inference) necesita un archivo de modelo
cuantizado (`.task`) que **no se incluye en el repositorio** porque pesa
entre 1 y 3 GB. Pasos:

1. Descarga un modelo compatible, por ejemplo **Gemma 2B/3B IT (cuantizado a
   int4)** desde Kaggle/Hugging Face, buscando "Gemma MediaPipe task file".
2. Copia el archivo al dispositivo (por USB o `adb push`) en:
   ```
   adb push gemma-2b-it-cpu-int4.task /data/local/tmp/model.task
   run-as com.offlineai.app mkdir -p files/models
   run-as com.offlineai.app cp /data/local/tmp/model.task files/models/model.task
   ```
   (o, más sencillo para desarrollo: añade una pantalla de "Importar modelo"
   con un `Intent.ACTION_OPEN_DOCUMENT` que copie el `.task` elegido por el
   usuario a `filesDir/models/model.task` — es el patrón recomendado para
   producción, ya que evita depender de `adb`).
3. Al abrir la app, `OfflineAiApp.onCreate()` carga automáticamente ese
   archivo con `LocalLlmEngine.initialize()`.

Sin este archivo, la app funciona igual (UI, cámara, OCR, guardado), pero el
asistente devolverá el aviso "El modelo local todavía no está cargado."

## Qué incluye cada parte

| Función | Implementación |
|---|---|
| Chat tipo ChatGPT | Jetpack Compose + Material 3 (`ChatScreen.kt`) |
| IA local | MediaPipe LLM Inference API + modelo Gemma cuantizado (`LocalLlmEngine.kt`) |
| Cámara | CameraX en vivo (`CameraCaptureScreen.kt`) |
| Galería | Photo Picker del sistema, sin permisos extra (`MainActivity.kt`) |
| OCR offline | ML Kit Text Recognition on-device (`OcrHelper.kt`) |
| Resolver ejercicios paso a paso | Prompt del sistema en `LocalLlmEngine.buildPrompt()` |
| Guardar chats e imágenes | Room (`AppDatabase.kt`) + almacenamiento interno (`ImageStorage.kt`) |
| Búsqueda en conversaciones | Consulta SQL `LIKE` en `ChatDao.searchConversations()` |
| Modo claro/oscuro | `OfflineAITheme` con toggle manual en la barra superior |

## Próximos pasos sugeridos

- Añadir una pantalla de "Importar modelo" (selector de archivos) en vez del
  método `adb push`, para que cualquier usuario pueda instalarlo sin PC.
- Añadir indicador de progreso de tokens/segundo y botón de "detener
  generación" (MediaPipe permite cancelar el streaming).
- Comprimir/redimensionar las imágenes antes de guardarlas (actualmente se
  guardan en JPEG calidad 90 sin límite de resolución).
- Tests instrumentados para `ChatRepository` con una base de datos Room en
  memoria.

## Nota de rendimiento

En un teléfono de gama media, un modelo de 2-4B parámetros cuantizado tarda
normalmente varios segundos en generar una respuesta y el APK final +
modelo puede ocupar 1.5–3 GB en disco. Es la naturaleza de correr un modelo
de lenguaje completo sin servidores: es la mejor relación calidad/velocidad
disponible hoy para "IA generativa 100% on-device" en Android.
